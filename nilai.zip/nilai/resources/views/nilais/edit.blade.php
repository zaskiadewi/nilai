<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>EDIT DATA NILAI</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body style="background: lightgray">

    <div class="container mt-5 mb-5">
        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow rounded">
                    <div class="card-body">
                        <form action="{{ route('nilais.update', $nilai->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            @method('PUT')

                            <div class="form-group">
                                <label class="font-weight-bold">NAMA</label>
                                <select class="form-control @error('id_siswa') is-invalid @enderror" name="id_siswa" size="1">
                                    {{-- Looping to populate student names --}}
                                    @foreach($siswas as $siswa)
                                        <option value="{{ $siswa->id }}" {{ ($nilai->id_siswa == $siswa->id) ? 'selected' : '' }}>{{ $siswa->nama }}</option>
                                    @endforeach
                                </select>

                                <!-- error message untuk kelas -->
                                @error('id_siswa')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>

                            <div class="form-group">
                                <label class="font-weight-bold">NAMA MAPEL</label>
                                <select class="form-control @error('id_mapel') is-invalid @enderror" name="id_mapel" id="id_mapel" size="1">
                                    @foreach($mapels as $mapel)
                                        <option value="{{ $mapel->id }}" {{ ($nilai->id_mapel == $mapel->id) ? 'selected' : '' }}>{{ $mapel->nama_mapel }}</option>
                                    @endforeach
                                </select>

                                <!-- error message untuk id_dudi -->
                                @error('id_mapel')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            
                            <div class="form-group">
                                <label class="font-weight-bold">NILAI</label>
                                <input type="number" class="form-control @error('nilai') is-invalid @enderror" name="nilai" value="{{ old('nilai', $nilai->nilai) }}" placeholder="Masukkan Nama Mapel">
                            
                                <!-- error message untuk title -->
                                @error('nilai')
                                    <div class="alert alert-danger mt-2">
                                        {{ $message }}
                                    </div>
                                @enderror
                            </div>
                            
                            <button type="submit" class="btn btn-md btn-primary">UPDATE</button>
                            <button type="reset" class="btn btn-md btn-warning">RESET</button>

                        </form> 
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            // Ketika pilihan DUDI berubah
            $('#id_mapel').change(function () {
                var selectedImage = $(this).find(':selected').data('image');
                // Ganti src gambar
                $('#gambar_barang').attr('src', selectedImage);
            });
        });
    </script>
</body>
</html>
