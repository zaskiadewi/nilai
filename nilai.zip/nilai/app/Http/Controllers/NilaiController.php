<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Nilai; 
use App\Models\Siswa; 
use App\Models\Mapel;

class NilaiController extends Controller
{
    public function index()
    {
        //get posts
        $nilais = Nilai::latest()->paginate(5);

        //render view with posts
        return view('nilais.index', compact('nilais'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $siswas = Siswa::all();
        $mapels = Mapel::all();

        return view('nilais.create', compact('siswas', 'mapels'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate form data
        $request->validate([
            'id_siswa' => 'required',
            'id_mapel' => 'required',
            'nilai' => 'required',
        ]);
    
        // Create a new Nilai instance
        Nilai::create([
            'id_siswa' => $request->id_siswa,
            'id_mapel' => $request->id_mapel,
            'nilai' => $request->nilai,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('nilais.index')->with('success', 'Data Nilai Berhasil Disimpan!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Nilai $nilai)
    {
        $siswas = Siswa::all();
        $mapels = Mapel::all();

        return view('nilais.edit', compact('nilai', 'siswas', 'mapels'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Nilai  $nilai
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Nilai $nilai)
    {
        // Validate form data
        $request->validate([
            'id_siswa' => 'required',
            'id_mapel' => 'required',
            'nilai' => 'required',
        ]);
    
        // Update Nilai instance
        $nilai->update([
            'id_siswa' => $request->id_siswa,
            'id_mapel' => $request->id_mapel,
            'nilai' => $request->nilai,
        ]);
    
        // Redirect to the index page with a success message
        return redirect()->route('nilais.index')->with('success', 'Data Nilai Berhasil Diperbarui!');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Nilai  $nilai
     * @return \Illuminate\Http\Response
     */
    public function destroy(Nilai $nilai)
    {
        $nilai->delete();
 
        return redirect()->route('nilais.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
